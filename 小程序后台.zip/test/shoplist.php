<?php
	include('./config.php');
	$action=$_GET['act'];
	switch($action){
		case 'shoptype':
			$uid=$_GET['uid'];
			$member=select_one("select * from xiaozu_member where uid='".$uid."'");
			if(!empty($member)){
				$templist=getarr("select id,shopname,shopicon from xiaozu_shop where loca='".$member['loca']."' and is_open=1 order by sort asc ");
			}else{
				$templist=getarr("select id,shopname,shopicon from xiaozu_shop where loca=1 and is_open=1 order by sort asc ");
			}
			
			foreach( $templist as  $k=>$v){
				$goodstype = getarr("select * from xiaozu_goodstype WHERE shopid = '".$v['id']."'  order by orderid asc");
				$v['goodstype'] = $goodstype;
				$templist[$k]   = $v;	  
			}
			$json=json_encode($templist);
			print_r($json);exit;
		break;

		default:
		break;
	}