<?php

	include('./config.php');
	$action=$_GET['act'];
	switch($action){
		case 'goods':
			$id=$_GET['id'];
			$goods=select_one("select * from xiaozu_goods where id='".$id."'");
			$json=json_encode($goods);
			print_r($json);exit;
		break;

		default:
			echo "操作错误";exit;
		break;
	}