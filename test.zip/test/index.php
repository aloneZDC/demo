<?php
	include('./config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>查询</title>
</head>
<style>
	.boblack{border:1px solid black;}
</style>
<body>
	<div>
		<table class='boblack' style='margin:0 auto;'>
			<tr>
				<td><a href='./add.php'>添加</a></td>
			</tr>
			<tr>
				<td class='boblack'>ID</td>
				<td class='boblack'>分类名</td>
				<td class='boblack'>描述</td>
				<td class='boblack'>操作</td>
			</tr>
			<?php
				$sql='select * from bg_cate order by cate_Id asc';
				$res=mysql_query($sql);
				while($row=mysql_fetch_assoc($res)){
					echo "<tr><td class='boblack'>".$row['cate_Id']."</td><td class='boblack'>".$row['cate_Name']."</td><td class='boblack'>".$row['cate_Intro']."</td><td class='boblack'><a href='./add.php?id=".$row['cate_Id']."'>修改</a> | <a href='./action.php?act=del&id=".$row['cate_Id']."'>删除</a></td></tr>";
				}
			?>
		</table>
	</div>
</body>
</html>