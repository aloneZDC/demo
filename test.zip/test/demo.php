<?php
header('content-type:text/html;charset=utf-8');
$cig=mysql_connect('127.0.0.1','root','root');
mysql_query('set names utf8');
mysql_select_db('weidogs',$cig);
$sql="select * from bg_cate";
$row=mysql_query($sql);
$getarr=array();
while($res=mysql_fetch_assoc($row)){
	$getarr[]=$res;
}

//递归(无限级分类)
function get_tree($data,$pid){
	$tree=array();
	foreach($data as $k=>$v){
		if($v['cate_ParentId']==$pid){
			$v['cate_ParentId']=get_tree($data,$v['cate_Id']);
			$tree[]=$v;
		}
	}
	return $tree;
}
$test=get_tree($getarr,0);
//输出HTML代码
function procHtml2($tree){
	$html = '';
	foreach($tree as $t){
  		if($t['cate_ParentId'] == ''){
   			$html .= "<li>{$t['cate_Name']}</li>";
  		}else{
   			$html .= "<li>".$t['cate_Name'];
   			$html .= procHtml($t['cate_ParentId']);
   			$html = $html."</li>";
  		}	
	}
	return $html ? '<ul>'.$html.'</ul>' : $html ;
}
$html=procHtml2($test);

//递归并生成下拉列表
function procHtml($parent_id=0,$n=-1){   
	$sql = "SELECT * FROM `bg_cate` WHERE `cate_ParentId` = '{$parent_id}'";   
	$options = '';   
	static $i = 0;   
	if ($i == 0){   
		$options .= '<option value="0" >请选择</option>';   
	}   
	$res = mysql_query($sql);   
	if ($res){   
		$n++;   
		while ($row = mysql_fetch_assoc($res)){   
			$i++;   
			$options .="<option value='{$row['cate_Id']}'";   
			$options .=">".str_repeat(' &nbsp;',$n*3).$row['cate_Name']."</option>\n";   
			$options .=procHtml ($row['cate_Id'],$n);   
		}   
	}   
	return $options;   
}
$html=procHtml();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>无限级分类</title>
</head>
<body>
	<select>
		<?php echo $html;?>
	</select>
</body>
</html>