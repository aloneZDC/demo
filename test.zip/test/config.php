<?php

header('content-type:text/html;charset=utf-8');
$cig=mysql_connect('127.0.0.1','root','root') or die('数据库连接失败');
mysql_query('set names utf8');
mysql_select_db('weidogs',$cig) or die('连接表失败');

function getarr($sql){
	$getarr=array();
	$res=mysql_query($sql);
	while($row=mysql_fetch_assoc($res)){
		$getarr[]=$row;
	}
	return $getarr;
}

function select_one($sql){
	$res=mysql_query($sql);
	$row=mysql_fetch_assoc($res);
	return $row;
}

function insert($dbname,$data){
	$feild='';
	$values='';
	foreach($data as $k=>$v){
		$feild.="`".$k."`,";
		$values.="'".$v."',";
	}
	$sql="INSERT INTO ".$dbname." (".substr($feild,0,-1).") VALUES (".substr($values,0,-1).")";
	$res=mysql_query($sql);
	return $res;
}

function update($dbname,$data,$where){
	$values='';
	foreach($data as $k=>$v){
		$values.="`".$k."`='".$v."',";
	}
	$sql="UPDATE ".$dbname." SET ".substr($values,0,-1)." where ".$where." ";
	$res=mysql_query($sql);
	return $res;
}

function catedelete($dbname,$where){
	$sql="DELETE FROM ".$dbname." where ".$where." ";
	$res=mysql_query($sql);
	return $res;
}

function query($sql){
	$res=mysql_query($sql);
	return $res;
}