<?php
	include('./config.php');
	if(empty($_GET['id'])){
		$title='添加';
		$type='add';
	}else{
		$title='修改';
		$type='edit';
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo $title;?></title>
</head>
<body>
	<form action="./action.php?act=<?php echo $type;?>" method='post'>
		<table style='margin:0 auto;'>
			<?php
				$id=$_GET['id'];
				$sql="select * from bg_cate where cate_Id='".$id."'";
				$res=mysql_query($sql);
				$row=mysql_fetch_assoc($res);
			?>
			<tr>
				<td>分类名</td>
				<td>
					<input type='text' name='cate_Name' value="<?php echo $row['cate_Name'];?>"/>
					<input type='hidden' name='cate_Id' value="<?php echo $row['cate_Id'];?>"/>
				</td>
			</tr>
			<tr>
				<td>描述</td>
				<td><textarea name='cate_Intro'><?php echo $row['cate_Intro'];?></textarea></td>
			</tr>
			<tr>
				<td><input type='submit' value='提交'/></td>
			</tr>
		</table>
	</form>
</body>
</html>