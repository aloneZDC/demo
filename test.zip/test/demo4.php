<?php
	header("content-type:text/html;charset=utf-8");
	$memcache=new Memcache();
	$memcache->connect('127.0.0.1', '11211'); 
	$blog = $memcache->get('redisrow');  
	//如果$blog数组为空，则去数据库中查询，并加入到memcache中  

	if(empty($blog)){
		echo 'mysql';
		// Connect mysql server 
		$mysql = new PDO("mysql:host=127.0.0.1;dbname=weidogs","root","root",array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));   
	    $rs = $mysql -> query("select * from bg_cate");  
	    //$row = $rs -> fetch();  
	    $i=0;  
	    while($row = $rs -> fetch()){   
	        $rows[$i]['title']=$row['cate_Name'];  
	        $rows[$i]['content']=$row['cate_Intro'];  
	        $i=$i+1;  
	    }  
	    print_r($rows);  
    	$redisrow = json_encode($rows);  
    	$memcache->set('redisrow',$redisrow);
	}else{
		$redisblog = json_decode($blog,true);  
    	echo "memcache";  
    	print_r($redisblog); 
	}
	

?>