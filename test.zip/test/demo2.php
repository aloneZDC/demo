<?php

$filename="./demo.txt";
$text="123456";
function wtext($filename,$text){
	$fp=fopen($filename,'a');
	fwrite($fp,$text);
	fclose($fp);
}

function ftext($filename,$text){
	file_put_contents($filename,$text,FILE_APPEND);
}

include('./config.php');
$sql="select * from bg_cate order by cate_Id asc";
$res=mysql_query($sql);
$getarr=array();
while($row=mysql_fetch_assoc($res)){
	$getarr[]=$row;
}

function gettree($data,$pid){
	$tree=array();
	foreach($data as $k=>$v){
		if($v['cate_ParentId']==$pid){
			$v['cate_ParentId']=gettree($data,$v['cate_Id']);
			$tree[]=$v;
		}
	}
	return $tree;
}

function procHtml($parent_id=0,$n=-1){   
	$sql = "SELECT * FROM `bg_cate` WHERE `cate_ParentId` = '{$parent_id}'";   
	$options = '';   
	static $i = 0;   
	if ($i == 0){   
		$options .= '<option value="0" >请选择</option>';   
	}   
	$res = mysql_query($sql);   
	if ($res){   
		$n++;   
		while ($row = mysql_fetch_assoc($res)){   
			$i++;   
			$options .="<option value='{$row['cate_Id']}'";
			$options .=">".str_repeat(' &nbsp;',$n*3).$row['cate_Name']."</option>\n";   
			$options .=procHtml ($row['cate_Id'],$n);   
		}   
	}   
	return $options;   
}
$html=procHtml();
echo "<select>".$html."</select>";

//查看当前IP
// print_r($_SERVER['REMOTE_ADDR']);

//去除重复数据
// $input = array("a" => "green","", "red","b" => "green", "","blue", "red","c" => "witer","hello","witer");
// $result = array_unique($input); //去除重复元素
// print_r($result);

// //插入3万数据
// $sql="INSERT INTO bg_test (`name`,`content`) VALUES ";
// for($i=0;$i<30000;$i++){
// 	$sql.="('".$i."','".$i."'),";
// };
// $sql = substr($sql,0,strlen($sql)-1);
// mysql_query($sql);